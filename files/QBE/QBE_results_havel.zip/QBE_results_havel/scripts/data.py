#!/usr/bin/env python

"""
Tools and parameters used in the notebooks
"""

from pathlib import Path
from collections import defaultdict
from functools import partial
import re
try:
    from ruamel import yaml

    to_yaml_str = partial(yaml.dump, stream=None, default_flow_style=False, encoding='utf-8', explicit_start=True, explicit_end=True, block_seq_indent=2)
    from_yaml_str = partial(yaml.load, Loader=yaml.loader.Loader)
except ImportError:
    import yaml

    class MyDumper(yaml.Dumper):
        def increase_indent(self, flow=False, indentless=False):
            return super().increase_indent(flow, False)

    to_yaml_str = partial(yaml.dump, stream=None, Dumper=MyDumper, default_flow_style=False, encoding='utf-8', explicit_start=True, explicit_end=True)
    from_yaml_str = yaml.load
# import pickle

import numpy as np
import pandas as pd
from sklearn import preprocessing


# ====================
#  Data file
# ====================
root = Path.cwd()
outputs = root / 'outputs'
data_file = root / 'data/smetradesmanliability.csv'

default_na_values = [# listed from doc of `pd.read_csv`
    '', '#N/A', '#N/A N/A', '#NA', '-1.#IND', '-1.#QNAN', '-NaN', '-nan',
    '1.#IND', '1.#QNAN', 'N/A', 'NA', 'NULL', 'NaN', 'n/a', 'nan', 'null'
]


def get_date_cols():
    """Return the names of the features with the word 'Date' inside"""
    reg = re.compile(r'.*[_ ]Date(\b|[0-9])(\Z|\s)')
    with data_file.open() as f:
        # columns on the first line
        cols = f.readline().split(',')
    return [_ for _ in cols if reg.match(_) is not None]


def read_data(mmap: bool=False):
    """Load the data in memory or in memory map file"""
    date_cols = get_date_cols()
    return pd.read_csv(
        data_file,
        index_col=0, engine='c', encoding='utf-8', low_memory=False, memory_map=mmap,
        parse_dates=date_cols, infer_datetime_format=True, dayfirst=True)


def get_dtypes(df: pd.DataFrame, verbose: bool=True):
    dtypes = defaultdict(list)
    n = df.shape[1]
    for _name, _type in df.dtypes.iteritems():
        dtypes[_type].append(_name)
    for _t in list(dtypes):
        dtypes[str(_t)] = dtypes[_t]
    if verbose:
        print(f'there are {len(dtypes)} different types')
    for _type, _list in dtypes.items():
        if isinstance(_type, str):
            continue
        _n = len(_list)
        if verbose:
            print(f'   - {_n:2d} ({_n/n*100.:4.1f}%) features of type "{_type}"')
    return dtypes


def apply_transform(df: pd.DataFrame, t: (bool, list, dict, callable), default, select_features: (list, dict)=False, name: str='transformer', inplace=True):
    """apply preprocessing transformation to the data"""
    if t is False:
        return {}

    # set default transform instance
    if default is None:
        tf = None
    elif isinstance(default, str):
        tf = getattr(preprocessing, default)()
    else:
        assert isinstance(default, dict), '`default` must be a string or a dict with keys "name" and optionaly "params"'
        tf = getattr(preprocessing, default['name'])(**default.get('params', {}))

    # features selection
    if select_features is False:
        pass
    elif select_features is None:
        select_features = {'dtype.kind': ('f', 'i'), 'min_unique': 3}
    elif isinstance(select_features, (list, tuple)):
        pass
    else:
        assert isinstance(select_features, dict), '`select_features` must be a dict, a list or None'
    
    features = []
    if select_features is False:
        features = list(df)
    elif isinstance(select_features, dict):
        features = list(df)
        if 'dtype.kind' in select_features or 'dtypes' in select_features:
            _dk = select_features.get('dtype.kind', select_features.get('dtypes', []))
            features = [_ for _ in features if df[_].dtype.kind in _dk]
        if 'min_unique' in select_features:
            _n = select_features['min_unique']
            features = [_ for _ in features if df[_].unique().size >= _n]
    else:
        features = select_features

    if t is True:
        assert tf is not None, 'you must provide a default scaler'
        t = tf
    elif callable(t):
        t = preprocessing.FunctionTransformer(t, validate=False, accept_sparse=False, pass_y=True)()
    elif not isinstance(t, dict):
        # a sequence of features to transform with default transformer
        features = t
        t = tf
    else:
        # a dict with the transformer's name for each feature
        _t = defaultdict(list)
        seen = {}
        for _f, _s in t.items():
            if _s in seen:
                _t[seen[_s]].append(_f)
            else:
                if isinstance(_s, str):
                    _ = getattr(preprocessing, _s)()
                else:
                    _ = getattr(preprocessing, _s['name'])(**_s.get('params', {}))
                seen[_s] = _
                _t[_].append(_f)
        t = _t
    
    # now apply transformers, inplace
    _o = {}
    if not inplace:
        df = df.copy()
    if isinstance(t, dict):
        for _t, _fl in t.items():
            x = df.loc[:, _fl].values
            xnew = _t.fit_transform(x)
            if xnew.shape == x.shape:
                df.loc[:, _fl] = xnew
            else:
                assert hasattr(_t, 'n_bins_'), 'a transformer returning a different X_new shape must have the attribute `n_bins_`'
                _new_fl = []
                nbins = _t.n_bins_
                for i, _ in enumerate(_fl):
                    if nbins[i] == 0:
                        continue
                    else:
                        _new_fl.extend([f'{_} = discretized bin #{j+1}' for j in range(nbins[i])])
                df.loc[:, _new_fl] = xnew

            _p = _t.get_params()
            _a = {_: getattr(_t, _) for _ in dir(_t) if _.endswith('_') and not _.startswith('_')}
            _o.update({_f: {name: _s.__class__.__name__, 'params': _p, 'fit_results': {_: _a[_][i] for _ in _a}, 'inst': _t} for i, _f in enumerate(_fl)})
    else:
        x = df.loc[:, features].values
        xnew = t.fit_transform(x)
        if xnew.shape == x.shape:
            df.loc[:, features] = xnew
        else:
            assert hasattr(t, 'n_bins_'), 'a transformer returning a different X_new shape must have the attribute `n_bins_`'
            _new_fl = []
            nbins = t.n_bins_
            for i, _ in enumerate(features):
                if nbins[i] == 0:
                    continue
                else:
                    _new_fl.extend([f'{_} = discretized bin #{j+1}' for j in range(nbins[i])])
            df.loc[:, _new_fl] = xnew
        _p = t.get_params()
        _a = {_: getattr(t, _) for _ in dir(t) if _.endswith('_') and not _.startswith('_')}
        tname = t.__class__.__name__
        if 'func' in _p:
            funcname = _p.pop('func').__name__
            _o.update({_f: {name: tname, 'params': _p, 'fit_results': {_: _a[_][i] for _ in _a}, 'func': funcname, 'inst': t} for i, _f in enumerate(features)})
        else:
            _o.update({_f: {name: tname, 'params': _p, 'fit_results': {_: _a[_][i] for _ in _a}, 'inst': t} for i, _f in enumerate(features)})
    if not inplace:
        return df, _o
    else:
        return _o


def finalize_data(df: pd.DataFrame, categoricals=None, onehot_feature_prefix_format='{name}=', cat_nan=False, cat_sparse=True, cat_drop_first=False,
                  cat_dtype=np.uint8, exclude_ohe_features=None, drop=None, transform: (dict, list)=None, scale: (bool, list, dict, callable)=False,
                  default_scaler='RobustScaler', scale_min_unique_values=3, discretize: (bool, list, dict)=False, default_discretizer='KBinsDiscretizer'):
    """will finalize the data so that it is ready to be used by ML algorithms. The following steps will be performed, in that order:
        - drop features
        - transform and drop features
        - scale features
        - discretize features (will be added to categoricals for one-hot-encoding ; TODO)
        - one-hot-encode categorical features
    """
    out = {}

    # always treat 'object', '', or 'categorical' dtype as categoricals
    dtypes = df.dtypes.astype(str)
    loc = dtypes.isin(('object', 'categorical'))
    f = set(dtypes.loc[loc].index.values)

    # which features are considered categoricals?
    if categoricals is None:
        categoricals = f
    else:
        categoricals = f.union(categoricals)
    if exclude_ohe_features is not None:
        categoricals = categoricals.difference(exclude_ohe_features)

    # drop features
    if drop is not None:
        drop = [_ for _ in drop if _ in df]
        df = df.drop(drop, axis=1)
        out['dropped'] = drop
        categoricals = categoricals.difference(drop)

    # transform and (optionally drop original after) features
    if transform is not None:
        if isinstance(transform, dict):
            transform = list(transform.items())
        _c = set()
        for _s, (_t, func, _drop) in transform:
            if not _s in df:
                continue
            df.loc[:, _t] = func(df.loc[:, _s])
            if _drop:
                _c.add(_s)
        df = df.drop(list(_c), axis=1)
        if 'dropped' in out:
            out['dropped'].extend(_c)
        else:
            out['dropped'] = list(_c)
    
    # scale features
    if scale:
        out['scaling'] = apply_transform(df, scale, default=default_scaler, name='scaler')
    
    # discretize features
    if discretize:
        out['discretizing'] = apply_transform(df, discretize, default=default_discretizer, name='discretizer')

    # one-hot-encoding features prefixes
    pf = onehot_feature_prefix_format.format
    prefix = {_: pf(name=_) for _ in categoricals}

    # one-hot-encode categorical features
    dat = pd.get_dummies(df, columns=list(categoricals),
                         prefix=prefix, prefix_sep='', dummy_na=cat_nan, sparse=cat_sparse, drop_first=cat_drop_first, dtype=cat_dtype)
    out['data'] = dat
    out['categoricals'] = categoricals

    ohe_f = list(set(dat).difference(df))
    out['ohe'] = ohe_f
    return out


def export(df: (pd.DataFrame, pd.Series), basename: str, path: Path=outputs, fmt='hdf5', hdf5_format='fixed', mode: str='w', append=False,
        complevel=5, complib='blosc:snappy', key=None, compression='bz2', finalization: dict=None):
    """export the data on disk, in the specified format"""
    # hdf5format in (table, fixed)
    fmt = fmt.lower()
    path = Path(path)
    if not path.is_dir():
        path.mkdir(parents=True)
    
    if fmt in ('hdf5', 'hdf', 'h5'):
        f = path / (basename + '.h5')
        df.to_hdf(str(f), basename if key is None else key, mode=mode, format=hdf5_format, append=append, complevel=complevel, complib=complib)
    else:
        # CSV
        assert fmt == 'csv', 'unsupported format for the export. Must be `hdf5` or `csv`'
        f = path / (basename + '.csv' + ('.' + compression if compression is not None else ''))
        df.to_csv(str(f), index=True, index_label='index', mode=mode, compression=compression, encoding='utf-8', )

    fdt = path / (basename + '_dtypes.yaml')
    if isinstance(df, pd.DataFrame):
        dtypes = df.dtypes.astype(str).to_dict()
    else:
        dtypes = {df.name: str(df.dtype)}
    fdt.write_bytes(to_yaml_str(dtypes))

    if finalization is not None:
        ff = path / f'{basename}_finalization_params.yaml'
        ff.write_bytes(to_yaml_str(finalization))
    return f


def load_export(basename: str, path: Path=outputs, fmt='hdf5', mmap: bool=True, key=None, compression='bz2', empty_str_is_nan: bool=False,
                finalize: bool=True):
    fmt = fmt.lower()
    path = Path(path)
    
    if fmt in ('hdf5', 'hdf', 'h5'):
        f = path / (basename + '.h5')
        df = pd.read_hdf(str(f), basename if key is None else key)
    else:
        assert fmt == 'csv', 'unsupported format for the export load. Must be `hdf5` or `csv`'
        f = path / (basename + '.csv' + ('.' + compression if compression is not None else ''))
        fdt = path / (basename + '_dtypes.yaml')
        opts = {}
        if fdt.is_file():
            # dtypes = pickle.loads(fdt.read_bytes())
            dtypes = from_yaml_str(fdt.read_bytes())
            dates = [_ for _, _dt in dtypes.items() if _dt.startswith('datetime')]
            obj = [_ for _, _dt in dtypes.items() if _dt in ('object', 'U')]
            if dates:
                for _ in dates:
                    dtypes[_] = object
                opts.update(parse_dates=dates, infer_datetime_format=True, dayfirst=True)
            if obj and not empty_str_is_nan:
                # empty string is considered as NaN
                opts.update(na_values={_: default_na_values[1:] for _ in obj}, keep_default_na=False)
        else:
            dtypes = None
        df = pd.read_csv(f, index_col=0, engine='c', encoding='utf-8', low_memory=dtypes is not None, dtype=dtypes, memory_map=mmap, **opts)

    ff = path / f'{basename}_finalization_params.yaml'
    if ff.is_file() and finalize:
        # finalization = pickle.loads(ff.read_bytes())
        finalization = from_yaml_str(ff.read_bytes())
        results = finalize_data(df, **finalization)
        return results  # True = applied finalization function
    elif finalize:
        return df
    else:
        return df