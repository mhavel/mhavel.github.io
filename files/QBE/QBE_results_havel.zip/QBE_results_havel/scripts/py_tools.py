#!/usr/bin/env python

"""
Python tools
"""

from pathlib import Path
from functools import partial
import pickle
try:
    from ruamel import yaml

    to_yaml_str = partial(yaml.dump, stream=None, default_flow_style=False, encoding='utf-8', explicit_start=True, explicit_end=True, block_seq_indent=2)
    from_yaml_str = partial(yaml.load, Loader=yaml.loader.Loader)
except ImportError:
    import yaml

    class MyDumper(yaml.Dumper):
        def increase_indent(self, flow=False, indentless=False):
            return super().increase_indent(flow, False)

    to_yaml_str = partial(yaml.dump, stream=None, Dumper=MyDumper, default_flow_style=False, encoding='utf-8', explicit_start=True, explicit_end=True)
    from_yaml_str = yaml.load

import numpy as np


def read_yaml(path: (str, Path)):
    return from_yaml_str(Path(path).read_bytes())


def write_yaml(path: (str, Path), data):
    y = to_yaml_str(data)
    Path(path).write_bytes(y)
    return y.decode('utf-8')


class InformationLogger:
    """
    A class to log information about eg. a model into a YAML file
    """
    _cache = {}  # log-key: [filepath, timestamp, data]

    def __init__(self, root: (str, Path)='outputs'):
        self.root = Path(root)
        if not self.root.is_dir():
            self.root.mkdir(parents=True)
    
    def _get_filepath(self, key, filename: str=None):
        c = self._cache.get(key, None)
        if c is None:
            if filename is None:
                f = self.root / f'{key}_info.yaml'.replace(' ', '_')
            else:
                f = self.root / (filename if filename.endswith('.yaml') else 'f{filename}.yaml')
            self._cache[key] = [f, -1, {}]
            return f
        else:
            return c[0]

    def _get_cache_or_read(self, key, cache: bool=True, update: bool=True):
        f = self._get_filepath(key)

        if not update:
            return {}
        if key in self._cache and cache:
            ts, d = self._cache[key][1:]
            try:
                m = f.stat().st_mtime
            except FileNotFoundError:
                return d
            if ts != m:
                return read_yaml(f)
            return d
        else:
            try:
                d = read_yaml(f)
            except FileNotFoundError:
                d = {}
            return d
    
    def _update_cache_and_write(self, key, data):
        f = self._get_filepath(key)
        write_yaml(f, data)
        self._cache[key] = [f, f.stat().st_mtime, data]

    def log(self, key, data: (str, dict, list, int, float, bool), update: bool=True, cache: bool=True, filename: str=None):
        f = self._get_filepath(key, filename)
        c = self._get_cache_or_read(key, cache=cache, update=update)
        c.update(data)
        self._update_cache_and_write(key, c)
        return f

    def log_xgb_model(self, key, dtrain, params, train_params, feature_names=None, with_results: bool=True,
            update: bool=True, cache: bool=True, filename: str=None, **kwargs):

        def _classes(d):
            y = d.get_label()
            cf = {_: float(y[y == _].size / y.size) for _ in np.unique(y).tolist()}
            return cf

        tp = {}
        ds = {
            'features': feature_names if feature_names is not None else dtrain.feature_names,
            'train': {'shape': [dtrain.num_row(), dtrain.num_col()], 'class_fractions': _classes(dtrain)}
        }
        for _k, _v in train_params.items():
            if _k == 'evals':
                tp[_k] = [_[1] for _ in _v]
                ds.update({_s: dict(shape=[_d.num_row(), _d.num_col()], class_fractions=_classes(_d)) for _d, _s in _v if _s not in ds})
            elif _k == 'evals_result':
                continue
            else:
                tp[_k] = _v
        data = {
            'data': ds,
            'params': params,
            'train_params': tp,
        }
        if with_results:
            # save in a pickle dump file
            res = train_params.get('evals_result', None)
            if res is not None:
                rf = self.root / f'{key}_evals_result.bin'
                rf.write_bytes(pickle.dumps(res, protocol=-1))
                data['evals_result'] = str(rf)
        data.update(kwargs)
        return self.log(key, data, update=update, cache=cache, filename=filename or f'{key}_model_info.yaml')

    def get_info(self, key, filename: str=None):
        f = self._get_filepath(key, filename)
        return self._get_cache_or_read(key, cache=True, update=True)

    def get_info_xgb_model(self, key, filename: str=None):
        return self.get_info(key, filename=filename or f'{key}_model_info.yaml')


def safe_eval(s: str):
    if not isinstance(s, str):
        return s
    try:
        x = eval(s, {'__builtins__': __builtins__}, {})
        return x
    except (NameError, SyntaxError):
        return s

def extend_lists_in_dict(d0: dict, d1: dict):
    for k, v in d0.items():
        if k not in d1:
            continue
        if isinstance(v, (list, tuple)):
            v.extend(d1[k])
        elif isinstance(v, np.ndarray):
            v = np.concatenate((v, d1[k]))
        elif isinstance(v, dict):
            extend_lists_in_dict(v, d1[k])
    for k, v in d1.items():
        if k not in d0:
            d0[k] = v