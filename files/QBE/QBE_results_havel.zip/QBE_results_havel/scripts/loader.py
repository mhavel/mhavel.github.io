#!/usr/bin/env python

"""
Tools and parameters used in the notebooks
"""

from pathlib import Path
from collections import defaultdict
from functools import reduce
import inspect
from types import ModuleType


class ScriptLoadingError(Exception):
    pass


class ScriptLoader:
    def __init__(self, prefix: (str, Path)=None):
        self._cwd = Path.cwd()
        self.prefix = self._cwd if prefix is None else Path(prefix).resolve()
        self.times = {}

        self._ev = {}
        self._listings = {}

        self._ns = None
        self._listing = None
        self._fname = None

    @property
    def namespace(self):
        return self._ns

    @property
    def listing(self):
        return self._listing

    @property
    def filename(self):
        return self._fname

    def load(self, path: (str, Path), env: dict=None, force: bool=False, listing_name='import_listing', filters: (str, list, tuple)='module'):
        """load the given script into the given environment (globals() by default)"""
        s = Path(path)
        if s.suffix != '.py':
            s = s.with_name(s.name + '.py')

        if not s.is_absolute():
            s = self.prefix / s

        # now, check the script is within cwd(),
        # and define `__package__` and `__name__` variables for the exec namespace to allow for relative imports in the script
        s = s.resolve()
        try:
            # the script must be within the current working folder!
            s.relative_to(self._cwd)
        except ValueError:
            raise ScriptLoadingError(f'the script must be rooted within "{self._cwd}"')
        _ = s.relative_to(self._cwd)
        _pkg = str(_.parent)
        _name = str(_.with_suffix('')).replace('/', '.')

        if not s.is_file():
            raise FileNotFoundError(f'the script "{s.name}" does not exists')
        
        if env is None:
            env = globals()
        else:
            assert isinstance(env, dict), '`env` must be None or a dict'

        t = self.times
        k = str(s.absolute())
        m = s.stat().st_mtime   # modification time
        if k not in t or force:
            t[k] = {'load': -1, 'modif': m}
        
        if t[k]['load'] != m:
            _env = {'__package__': _pkg, '__name__': _name}
            exec(s.read_bytes(), _env, _env)

            if listing_name in _env:
                listing = _env[listing_name]
            else:
                listing = self.make_listing(_env)
            
            if filters is not None:
                if isinstance(filters, str) and filters in listing:
                    del listing[filters]
                else:
                    listing = {_k: _v for _k, _v in listing.items() if _k not in filters}
            env.update({_: _env[_] for _ in reduce(lambda _x, _y: _x + _y, listing.values(), [])})
            t[k] = {'load': m, 'modif': m}
            print(f'script "{s.name}" read and loaded into namespace')
            self._ns = _env
            self._listing = listing
            self._fname = k
        else:
            self._ns = self._listing = None
            self._fname = k
            print(f'script "{s.name}" have not changed. Not reading again')
        
        return

    @staticmethod
    def make_listing(env: dict=None, exclude: (tuple, list)=None):
        if exclude is None:
            ev = []
        else:
            ev = exclude
        if env is None:
            env = locals()
        listing = defaultdict(list)

        for _x, _v in list(env.items()):
            if _x.startswith('_') or _x in ev:
                continue
            if inspect.isclass(_v):
                listing['class'].append(_x)
            elif callable(_v):
                listing['function'].append(_x)
            elif isinstance(_v, ModuleType):
                listing['module'].append(_x)
            else:
                listing['variable'].append(_x)
        return listing

    def start_import(self):
        """exclude every variable until now"""
        self._ev[__file__] = [_ for _ in list(locals())]

    def stop_import(self):
        """make a listing, per category of each variable to import"""
        ev = self.ev[__file__]
        listing = self._listings[__file__] = self.make_listing(locals(), self.ev[__file__])
        return listing
