#!/usr/bin/env python

"""
Tools to train a classification model
"""

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split


def get_classes(y, first_dropped: bool=False):
    if isinstance(y, pd.Series):
        c = np.sort(y.unique())
        n = c.size
        locs = {_: y == _ for _ in c}
        num = {_c: y.loc[_l].size for _c, _l in locs.items()}
    else:
        # one-hot-encoded with 0 and 1
        n = y.shape[1]
        c = list(y)
        if first_dropped:
            n = y.shape[1] + 1
            locs = {_: y.loc[:, _] == 1 for _ in y}
            locs['dropped'] = y.sum() == 0
            c += ['dropped']
        else:
            locs = {_: y.loc[:, _] == 1 for _ in y}
        num = {_c: y.loc[_l].size for _c, _l in locs.items()}
    return c, num, locs


def fraction_to_number(x, classes, npc, ntot):
    if x is None:
        return x
    if isinstance(x, float):
        assert 0 <= x <= 1., f'fraction must be between 0 and 1 (got {x:.3g})'
        y = int(x * ntot)
    elif not isinstance(x, int):
        y = []
        assert len(x) == len(classes), f'length of tuples must match the number of classes, {len(classes)}'
        for i, e in enumerate(x):
            c = classes[i]
            if isinstance(e, float):
                assert 0 <= e <= 1., f'fraction must be between 0 and 1 (got {e:.3g})'
                e = int(e * npc[c])
            else:
                assert e <= npc[c], f'cannot pick more than the total number of samples in classes `{c}`, {e > npc[c]}'
            y.append(e)
    else:
        y = x
    return y


def split_train_dev_test(x: pd.DataFrame, y: (pd.DataFrame, pd.Series),
        dev: (tuple, int, float)=None, test: (tuple, int, float)=None, train: (tuple, int, float)=None,
        shuffle: bool=True, stratify: bool=True, first_dropped: bool=False, classes=None, random_state=None):
    """split input data into 2 or 3 sets: train, dev, and optionally test

    If an int is given: take that number of samples
    If a float is given: take that fraction of samples
    If a tuple is given, its length must corresponds to the number of classes, and each value must be an int or a float with the same meaning as above,
    but for the samples belonging to the respective classes

    Use stratify K-fold by default (when dealing with an int or a float).

    First, split train + not_train, then not_train is either split into dev + test or set to dev
    """
    _, npc, locs = get_classes(y)
    if classes is None:
        classes = _
    nc = len(classes)
    ntot = sum(npc.values())
    
    is_tuple = [not isinstance(_, (int, float)) for _ in (train, test, dev) if _ is not None]
    assert all(is_tuple) or not any(is_tuple), 'either all values are tuples, or all are int or float'

    train = fraction_to_number(train, classes, npc, ntot)
    dev = fraction_to_number(dev, classes, npc, ntot)
    test = fraction_to_number(test, classes, npc, ntot)

    _ns = sum([_ if isinstance(_, int) else sum(_) for _ in (train, test, dev) if _ is not None])
    if _ns > ntot:
        raise ValueError(f'number of samples for all sets is greater than number of samples in data ({_ns} > {ntot})')

    if train is None:
        if test is None:
            assert dev is not None, 'either `train` or `dev` must be given'
            if not isinstance(dev, int):
                train = [npc[_i] - _v for _i, _v in enumerate(dev)]
            else:
                train = ntot - dev
        elif dev is None:
            dev = test
            if not isinstance(dev, int):
                train = [npc[_i] - 2 * _v for _i, _v in enumerate(dev)]
            else:
                train = ntot - 2 * dev
    
    elif test is None:
        if dev is None:
            if not isinstance(train, int):
                dev = [npc[_i] - _v for _i, _v in enumerate(train)]
            else:
                dev = ntot - train
    
    else:
        if dev is None:
            if not isinstance(test, int):
                dev = [npc[_i] - _v0 - _v1 for _i, (_v0, _v1) in enumerate(zip(test, train))]
            else:
                dev = ntot - train - test

    print(f'classes are: {classes}')
    print(f'train split = {train}')
    print(f'dev   split = {dev}')
    print(f'test  split = {test}')

    if not any(is_tuple):
        if test is None:
            x_train, y_train, x_dev, y_dev = train_test_split(
                x, y, test_size=dev, train_size=train,
                random_state=random_state, shuffle=shuffle, stratify=y if stratify else None
            )
            return (x_train, y_train), (x_dev, y_dev)
        else:
            x_train, x_, y_train, y_ = train_test_split(
                x, y, train_size=train, test_size=None, random_state=random_state, shuffle=shuffle, stratify=y if stratify else None
            )
            x_dev, x_test, y_dev, y_test = train_test_split(
                x_, y_, train_size=dev, test_size=test, shuffle=shuffle, stratify=y_ if stratify else None
            )
            return (x_train, y_train), (x_dev, y_dev), (x_test, y_test)
    
    else:
        if isinstance(random_state, np.random.RandomState):
            rs = random_state
        else:
            rs = np.random.RandomState(random_state)
        c_idx = {}
        for c in classes:
            idx = y.loc[locs[c]].index.values.copy()
            if shuffle:
                rs.shuffle(idx)
            c_idx[c] = idx
        
        # train
        idx = np.concatenate([c_idx[c][:train[i]] for i, c in enumerate(classes)])
        x_train = x.loc[idx]
        y_train = y.loc[idx]

        # dev
        idx = np.concatenate([c_idx[c][train[i]:train[i]+dev[i]] for i, c in enumerate(classes)])
        x_dev = x.loc[idx]
        y_dev = y.loc[idx]

        # test
        if test is not None:
            idx = np.concatenate([c_idx[c][train[i]+dev[i]:train[i]+dev[i]+test[i]] for i, c in enumerate(classes)])
            x_test = x.loc[idx]
            y_test = y.loc[idx]
            return (x_train, y_train), (x_dev, y_dev), (x_test, y_test)
        else:
            return (x_train, y_train), (x_dev, y_dev)


def balanced_resampling(df: pd.DataFrame, ):
    pass
