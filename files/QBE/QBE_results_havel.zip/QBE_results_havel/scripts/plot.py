#!/usr/bin/env python

"""
Plotting tools
"""

from functools import reduce

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb

from sklearn.feature_selection import chi2, f_classif, mutual_info_classif



class CyclingBatchSlices:
    def __init__(self, array, batch_size: int, max_cycles: int=None, start: int=0, stop: int=None, step: int=None):
        self.a = np.asarray(array)[start:stop:step]
        self.s = batch_size
        self.nc = max_cycles

        self._n = len(self.a)
        self._ic = 0
        self._i0 = 0

    @property
    def array(self):
        return self.a

    @property
    def cycle(self):
        return self._ic
    
    def shuffle(self, seed=None, restart=True, copy=True):
        if isinstance(seed, np.random.RandomState):
            rs = seed
        else:
            rs = np.random.RandomState(seed=seed)
        if copy:
            self.a = self.a.copy()
        rs.shuffle(self.a)
        if restart:
            self._i0 = 0

    def at_start(self):
        self._i0 = 0

    def __iter__(self):
        return self

    def __next__(self):
        i = self._i0
        s = self.s
        a = self.a
        j = i + s
        if j > self._n:
            nc = self.nc
            if nc is not None:
                if self._ic == nc:
                    raise StopIteration
            n1 = self._n - i
            n0 = s - n1
            b = np.concatenate((a[i:i+n1], a[:n0]))
            i = n0
            self._ic += 1
        else:
            b = a[i:j]
            i = j
        self._i0 = i
        return b


def compute_corr_scores_classif(x: pd.DataFrame, y: pd.Series, *metrics: str, split: bool=True, ratio: float=1., random_seed=None, runs: int=1):
    """compute F-score, mutual information, and/or chi2 (keywords: f, mi, chi2)

    For now, only binary class are supported

    if `split` is True, split the datasets so that there are approximately equal number of samples in each class for each set
    """
    # split into k sets, where k = max(1, ceil(#(no claims) / #(claims)))
    m, n = x.shape

    classes = y.unique()
    nc = len(classes)
    
    rs = np.random.RandomState(seed=random_seed)

    yc = [y.loc[y == _] for _ in classes]
    ys = [_.size for _ in yc]
    idx = []
    for i, _ in enumerate(classes):
        _i = yc[i].index.values
        rs.shuffle(_i)
        idx.append(_i.tolist())

    k = 1
    ns = m
    if split:
        # assert classes.size == 2, 'only binary classes is supported for now when splitting into multiple sets'
        n1, n0 = min(ys), max(ys)
        i1, i0 = ys.index(n0), ys.index(n1)
        print(f'splitting has been required. There are {nc} classes, and we will balance them according to the majority and minority classes,'
              f'"{classes[i0]}" ({ys[i0]/m*100:.2f}%) and "{classes[i1]}" ({ys[i1]/m*100:.2f}%) resp.')
        assert ratio >= 1., 'ratio must be higher than 1.'
        fr = ratio + 1.
        if n1 < n0 / fr:
            k = int(max(1, np.ceil(1. * n0 / ratio / n1)))
            print(f'splitting into {k} sets')
            nsizes = [int(np.ceil(min(ratio * n1, _))) for _ in ys]
            ns = sum(nsizes)
        else:
            split = False

    scores = {}
    fmap = {}
    for _ in metrics:
        if _ in ('f', 'f-test', 'f-score'):
            scores['f_test'] = np.zeros((k, x.shape[1]), dtype=float)
            fmap['f_test'] = f_classif
        elif _ in ('mi', 'mutual_information', 'mutual information'):
            scores['mi'] = np.zeros((k, x.shape[1]), dtype=float)
            fmap['mi'] = mutual_info_classif
        elif _ == 'chi2':
            scores['chi2'] = np.ones((k, x.shape[1]), dtype=float)
            fmap['chi2'] = chi2
    
    if split:
        slices = [CyclingBatchSlices(idx[_], nsizes[_]) for _ in range(nc)]

        for r in range(runs):
            if r:
                _ = [_.shuffle(rs, copy=True) for _ in slices]
            print(f'>> starting run #{r+1}...')
            print('  doing set', end=' ')
            for i in range(k):
                loc = reduce(lambda _x, _y: _x + _y, (next(_s).tolist() for _s in slices), [])
                if i == k -1:
                    print(f'last set ({i+1}).')
                else:
                    print(f'{i+1}', end=', ')
                assert y.loc[loc].size <= ns
                for _, s in scores.items():
                    func = fmap[_]
                    if _ == 'mi':
                        _s = func(x.loc[loc], y.loc[loc])
                    else:
                        _s, _p = func(x.loc[loc], y.loc[loc])
                    s[i, :] += _s  # / np.nanmax(_s)
        if runs > 1:
            for _, s in scores.items():
                s /= runs
        print(f'done')
    
    else:
        for _, s in scores.items():
            func = fmap[_]
            if _ == 'mi':
                _s = func(x, y)
            else:
                _s, _p = func(x, y)
            s[0, :] = _s

    return scores


def plot_split_scores(scores, features: list=None, metric_name: str='score', parts='swarm, half-vline', norm: str='set', palette=None, notch=True,
                      orient='h', pt_color='red'):
    """build a boxplot for each feature, showing the results of the correlation scores (from `compute_corr_scores_classif`)"""
    if features is None:
        features = np.arange(1, scores.shape[1]+1, dtype=str)
    d = pd.DataFrame(scores, columns=features, copy=False)

    # normalize, per set
    if norm == 'set':
        x = d.divide(d.max(axis=1, skipna=True), axis=0)
    # normalize across all sets
    elif norm == 'all':
        x = d / d.max(axis=1).max()
    # no normalization
    else:
        x = d

    if palette is None:
        # palette = sb.diverging_palette(10, 220, sep=80, n=scores.shape[1])
        palette = sb.diverging_palette(255, 133, l=60, n=7, center="dark")
    ax = sb.boxplot(data=x, palette=palette, notch=notch, orient=orient)
    if 'swarm' in parts:
        sb.swarmplot(data=x, size=2, color=pt_color, linewidth=0, orient=orient)
    if 'half-vline' in parts:
        ax.axvline(x=x.max(axis=0).ptp() / 2. + x.min().min(), lw=2, c=pt_color)
    if norm is not None:
        ax.set_xlabel(metric_name + f' (norm. on `{norm}`)')
    else:
        ax.set_xlabel(metric_name)
    sb.despine(offset=10, trim=False)
    return ax


def plot_fractions_per_classes(x: pd.DataFrame, classes: list, fracs: dict, bin_edges: dict, parts='hist, rug', class_legend=None,
                               class_colors=None, color_palette=None):
    """build a table of plots, one for each features, from binned data sets, showing the fractions of each class within its bin"""
    m, n = x.shape
    ncol = min(3, m)  # 3 cols max.
    nrow = int(np.ceil(max(1, n / ncol)))
    cols = list(x)

    fig, axes = plt.subplots(nrow, ncol, figsize=(15, 10), sharey=True)
    k = 0
    if class_colors is None:
        if color_palette is None:
            colors = sb.color_palette('Set2', n_colors=len(classes))
        elif isinstance(color_palette, str):
            colors = sb.color_palette(color_palette, n_colors=len(classes))
        else:
            colors = color_palette
    else:
        colors = class_colors
    # colors = ('#42a5f5', '#ffb300')
    lines = []
    if class_legend is not None:
        if isinstance(class_legend, dict):
            legends = [class_legend[_] for _ in classes]
        else:
            legends = class_legend
    else:
        legends = classes.astype(str)
    for i in range(nrow):
        for j in range(ncol):
            f = cols[k]
            k += 1
            ax = axes[i, j]
            if j == 0:
                ax.set_ylabel('fraction per bin')
            bottom = 0
            
            line_1 = []
            for _, c in enumerate(classes):
                _h = fracs[c][f]
                be = bin_edges[f]
                line_1.append(ax.bar(be[:-1], _h, width=np.diff(be), bottom=bottom, align='edge', color=colors[_]))
                bottom = _h
            
            if 'hist' in parts:
                hh, xbe = np.histogram(x.loc[:, f], bins=40)
                hh = hh.astype(float) / (np.nanmax((np.nanmax(hh) * 1.2, 0)))
                line_2 = ax.bar(xbe[:-1], hh, width=np.diff(xbe), align='edge',
                        edgecolor='#e53935', linewidth=3, fill=False)
                if k == 1:
                    lines.append(line_2)
                    legends.append('overall hist.')
            if 'rug' in parts:
                line_3 = sb.rugplot(x.loc[:, f], color='black', ax=ax, height=0.05)
            ax.set_xlabel(f)
    fig.legend(line_1 + lines, legends)
    fig.subplots_adjust(hspace=0.6)
    return fig
