#!/usr/bin/env python

"""
testing relative import
"""


from . import data

print(data.default_na_values)

