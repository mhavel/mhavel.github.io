#!/usr/bin/env python

"""
Data / features selection parameters and tools
"""

from collections import OrderedDict
from functools import reduce, partial

import pandas as pd
import numpy as np


# ====================
#  Features: settings
# ====================
# an exclusion list, with the main reason why we exclude it
features_exclusion = {
    'leaking': [# features that are related to the target, hence should not be used
        'Claim Incurred',
        'Capped Incurred (£50k)',
        'Capped Incurred (£100k)'
    ],
    'has_proxy': [# features that have a simpler sibling (proxy) that could be used alone (probably)
        'Trade 1',
        'Trade 2'
    ]
}

# new features
def _feat_claim_flag(df: pd.DataFrame, name: str, force: bool=False, **kwargs):
    """Make a new feature: `Claim Flag`, = 0 when no claims, = 1 otherwise (regardless of the number of claims)"""
    if name in df and not force:
        return
    
    df.loc[:, name] = s = df['Claim Count'].copy()
    df.loc[s >= 1, name] = 1
    return


new_features = OrderedDict((
    ('Claim Flag', _feat_claim_flag),
))


# ====================
#  Target
# ====================
# target(s)
class Target:
    """
    a class to hold the currently known targets and the selected one

    Methods:
        declare(*targets) -> t : declare, without setting, targets ; t is the last target declared
        choose(i) -> t : pick/activate among the known targets, the i-th ; t is the selected and activated target
        set(target) -> t : declare and activate a (possibly new) target
        get() -> t : get the currently active target
    
    Properties:
        name: the active target
    """
    def __init__(self, *targets, allow_multiple: bool=False):
        self._m = allow_multiple
        self._t = None
        self.known = []
        self._t = self.declare(*targets)

    def declare(self, *targets):
        _t = None
        for t in targets:
            _t = self._check(t)
            if _t not in self.known:
                self.known.append(_t)
        return _t

    def _check(self, t):
        if isinstance(t, (list, tuple, np.ndarray)):
            if len(t) == 1:
                _t = t[0]
            elif not self._m:
                raise ValueError('`target` must be a single feature')
            else:
                _t = list(t)
        else:
            _t = t
        return _t

    def choose(self, i: int):
        self._t = self.known[i]
        return self._t

    def set(self, t):
        self._t = self.declare(t)
        return self._t

    @property
    def name(self):
        return self._t

    names = name

    def get(self):
        return self._t

    def __iter__(self):
        self._i = 0
        return self
    
    def __next__(self):
        i = self._i
        k = self.known
        if i < len(k):
            return k[i]
        else:
            raise StopIteration
    
    def flatten_known(self):
        l = []
        for _ in self.known:
            if isinstance(_, list):
                l.extend(_)
            else:
                l.append(_)
        return l

    def others(self, flatten: bool=False):
        k = self.known
        i = k.index(self._t)
        f = [k[_] for _ in range(len(k)) if _ != i]
        if flatten:
            return reduce(lambda _x, _y: _x + _y if isinstance(_y, list) else _x + [_y], f, [])
        else:
            return f


target = Target('Claim Flag', 'Claim Count', allow_multiple=False)



# ====================
#  Transforms
# ====================
class TransformsLockedError(BaseException):
    pass


class Transforms:
    def __init__(self):
        self.transforms = []
        self.func_names = []
        self._locked = False

    @property
    def pipeline(self):
        return self.func_names

    def __len__(self):
        return len(self.transforms)

    def lock(self):
        self._locked = True

    def unlock(self):
        self._locked = False

    def _check_lock(self):
        if self._locked:
            raise TransformsLockedError()

    def add(self, func: callable, *args, **kwargs):
        self._check_lock()
        self.transforms.append(partial(func, *args, **kwargs))
        self.func_names.append(func.__name__)

    def add_once(self, func: callable, *args, **kwargs):
        self._check_lock()
        name = func.__name__
        if name in self.func_names:
            i = self.func_names.index(name)
            self.transforms[i] = partial(func, *args, **kwargs)
        else:
            self.add(func, *args, **kwargs)

    def apply(self, df: pd.DataFrame):
        for t in self.transforms:
            t(df)


transforms = Transforms()


# ====================
#  Functions
# ====================
def make_new_features(df: pd.DataFrame, transforms: Transforms=transforms, **kwargs):
    """based on `new_features`, add new feature inplace to the given dataframe"""
    for f, func in new_features.items():
        func(df, f, **kwargs)
    if transforms is not None:
        transforms.add_once(make_new_features, transforms=None)
    return


def split_xyz(df: pd.DataFrame, remove_leaking: bool=True):
    """based on `features_exclusion` and `target`, separate data as X=input features, Y=target features, Z=removed (leaking + other targets) features"""
    y = df.loc[:, target.name]
    
    z = None
    o = target.others(flatten=True)
    if o:
        z = df.loc[:, o]

    x = df.drop(target.flatten_known(), axis=1)

    if remove_leaking:
        l = features_exclusion.get('leaking', [])
        if l:
            if z is None:
                z = x.loc[:, ]
            else:
                z = z.merge(x.loc[:, l], left_index=True, right_index=True, copy=False)
            x.drop(l, axis=1, inplace=True)
    return x, y, z


def exclude_features(df: pd.DataFrame, what: (str, list)=None, return_removed: (bool, pd.DataFrame)=True):
    """exclude the features in `features_exclusion` dict from data"""
    if isinstance(what, int) and what == 0:
        return df
    elif what is not None:
        if isinstance(what, str):
            fl = features_exclusion.get(what, what)
        else:
            fl = []
            for w in what:
                fl.extend(features_exclusion.get(w, w))  # maybe `what` is a feature name instead of an exclusion group name
    else:
        fl = reduce(lambda _x, _y: _x + _y, features_exclusion.values(), [])
    
    fl = [_ for _ in fl if _ in df]
    if not fl:
        if isinstance(return_removed, pd.DataFrame):
            return df, return_removed
        elif isinstance(return_removed, True):
            return df, None
        else:
            return df
    if not (return_removed is False):
        if isinstance(return_removed, pd.DataFrame):
            r = return_removed
            r = r.merge(df.loc[:, fl], copy=False, left_index=True, right_index=True)
        else:
            r = df.loc[:, fl]
        df.drop(fl, axis=1, inplace=True)
        return df, r
    else:
        df.drop(fl, axis=1, inplace=True)
        return df
    

def drop_features(df: pd.DataFrame, names):
    """simply drop the given features in the data"""
    fl = [_ for _ in names if _ in df]
    df.drop(fl, axis=1, inplace=True)


def clean_texts(df: pd.DataFrame, replace_nan_with: str=None, flag_nan: bool=True, always_flag_nan: bool=False,
                nan_flag_suffix: str='_nan_flag', transforms: Transforms=transforms):
    """clean texts features by simply removing trailing/leading spaces and putting all in lower case"""
    nan2x = {}
    new_flags = {}
    for c in df:
        s = df.loc[:, c]
        if s.dtype.kind in ('O', 'U'):
            df.loc[:, c] = s.str.strip().str.lower()
            if replace_nan_with is not None:
                loc = s.isnull()
                if not s.loc[loc].size:
                    continue
                nan2x[c] = replace_nan_with
                if flag_nan:
                    uv = s.value_counts().index.values.astype(str)
                    if replace_nan_with in uv or always_flag_nan:
                        flag_nan_series(df, c, c + nan_flag_suffix, reverse=True, notnan_loc=(~loc))
                        new_flags[c + nan_flag_suffix] = c
                df.loc[loc, c] = replace_nan_with
                    
    if transforms is not None:
        transforms.add_once(clean_texts, replace_nan_with=False, transforms=None)  # NaN replacements are done below
        if replace_nan_with is not None:
            transforms.add(_apply_nan_replacement, nan2x=nan2x, new_flags=new_flags, reverse_flag=True)
    return


def exclude_non_informative(df: pd.DataFrame, dtypes_kind=('f', 'O', 'U', 'i'), transforms: Transforms=transforms):
    """exclude uninformative float and/or string features, ie. with only one value (and for texts, NaN or empty strings only)"""
    nan_str = str(np.nan)

    removed = {}
    for c in df:
        s = df.loc[:, c]
        k = s.dtype.kind 
        
        if k not in dtypes_kind:
            continue
        
        if k in ('O', 'U'):
            nan = (s == nan_str) | (s == '')
        elif k == 'f':
            nan = s.isnull()
        else:
            nan = np.zeros(s.size, dtype=bool)
        
        if df.loc[nan, c].shape[0] == df.shape[0]:
            removed[c] = 'uninformative'
            continue
        vc = s.value_counts()
        if vc.size == 1:
            removed[c] = 'unique value'
            continue
    df.drop(list(removed), axis=1, inplace=True)
    if transforms is not None:
        transforms.add(drop_features, list(removed))
    return removed


def pick_nan_replacement(s: pd.Series):
    """given a series (without NaNs), (try to) choose a reasonable value for the NaN values. If not easy, return None"""
    low = s.min()
    upp = s.max()
    if low > 0 or upp < 0:
        r = 0.
    elif low >= 0.:
        r = -1.
    elif upp <= 0:
        r = 1.
    else:
        r = None
    return r


def flag_nan_series(df: pd.DataFrame, name: str, flag_name: str, reverse: bool=True, notnan_loc=None):
    s = df.loc[:, name]
    c = flag_name
    assert c not in df, f'NaN flag feature "{c}" already in dataframe. Choose a different flag suffix ({flag_name.replace(name, "")})'

    df.loc[:, c] = np.zeros(df.shape[0], dtype=int)
    if notnan_loc is None:
        loc = s.notnull()
    else:
        loc = notnan_loc
    if reverse:
        df.loc[loc, c] = 1
    else:
        df.loc[~loc, c] = 0
    return s.loc[~loc].size


def _apply_nan_replacement(df: pd.DataFrame, nan2x: dict, new_flags: dict=None, reverse_flag: bool=True):
    if new_flags is None:
        flag_in = {}
    else:
        flag_in = {_v: _k for _k, _v in new_flags.items()}
    counts = {}
    for f, r in nan2x.items():
        s = df.loc[:, f]
        df.loc[s.isnull(), f] = r
        cf = flag_in.get(f, None)
        if cf is not None:
            n = flag_nan_series(df, f, cf, reverse=reverse_flag)
            counts[f] = n
    return counts


def replace_float_nan(df: pd.DataFrame, create_flags: bool=True, replacement: (callable, float)=pick_nan_replacement,
        flag_col_suffix: str='_nan_flag', reverse_flag: bool=True, always_flag: bool=False, transforms: Transforms=transforms):
    """replace float NaN values in the data"""
    new_flags = {}
    nan2x = {}
    nan_counts = {}

    for c in list(df):
        s = df.loc[:, c]
        k = s.dtype.kind

        if k != 'f':
            continue

        loc = s.notnull()
        if s.loc[loc].size == s.size:
            continue        
        
        flag = always_flag
        if callable(replacement):
            r = replacement(s.loc[loc])
            if r is None:
                x = s.loc[loc]
                r = x.min() - x.std()  # might not be the best value to pick!
                flag = True
        else:
            r = replacement
        
        if flag:
            cf = c + flag_col_suffix
            n = flag_nan_series(df, c, cf, reverse=reverse_flag, notnan_loc=loc)
            new_flags[cf] = c
            nan_counts[c] = n
        else:
            nan_counts[c] = s.loc[~loc].size

        nan2x[c] = r
        df.loc[~loc, c] = r

    if transforms is not None and nan2x:
        transforms.add(_apply_nan_replacement, nan2x=nan2x, new_flags=new_flags, reverse_flag=reverse_flag)
    return nan2x, new_flags, nan_counts


def split_date_periods(df: pd.DataFrame, *date_pairs, split_into=('year', 'month', 'day'), compute_duration: bool=True, duration_components='days',
                       round: str='D', split_names=None, suffix_fmt: str=' [{fmt_name}]', inplace: bool=True, drop_originals: bool=False,
                       transforms: Transforms=transforms):
    """takes a sequence of date features (one or a pair in a tuple), and split it into components. If a pair is provided, you can ask to
    compute the duration, split into duration components. Each date or timedelta components is either an int or a float"""
    if isinstance(split_into, str):
        split_into = [split_into]

    if split_names is None:
        split_names = split_into

    if not inplace:
        df = df.copy()

    originals = []
    for pair in date_pairs:
        if not isinstance(pair, tuple):
            s0 = df.loc[:, pair]
            s1 = None
            assert s0.dtype.kind == 'M', f'features must be of `datetime` dtype (error with: {s0.name})'
            originals.append(s0.name)
        else:
            s0 = df.loc[:, pair[0]]
            s1 = df.loc[:, pair[1]]
            assert s0.dtype.kind == 'M', f'features must be of `datetime` dtype (error with: {s0.name})'
            assert s1.dtype.kind == 'M', f'features must be of `datetime` dtype (error with: {s1.name})'
            originals.extend((s0.name, s1.name))

        for _fmt, _name in zip(split_into, split_names):
            c = f'{s0.name}{suffix_fmt.format(fmt_name=_name)}'
            if '%' in _fmt:
                df.loc[:, c] = s0.dt.strftime(_fmt)
            else:
                df.loc[:, c] = getattr(s0.dt, _fmt)

        if compute_duration and s1 is not None:
            td = s1 - s0
            c0 = f'{s1.name} - {s0.name}'
            if round:
                td = td.dt.round(round)
            if isinstance(duration_components, str):
                _name = duration_components
                c1 = f'{c0} [{_name}]'
                if hasattr(td.dt, duration_components):
                    td = getattr(td.dt, duration_components)
                else:
                    td = td.dt.compoments[duration_components]
                df.loc[:, c1] = td
            else:
                td = td.dt.components[duration_components]
                for _ in duration_components:
                    df.loc[:, f'{c0} [{_}]'] = td[_]
        elif s1 is not None:
            for _fmt, _name in zip(split_into, split_names):
                c = f'{s1.name}{suffix_fmt.format(fmt_name=_name)}'
                df.loc[:, c] = s1.dt.strftime(_fmt)
        
        if drop_originals:
            drop_features(df, originals)

        if transforms is not None:
            transforms.add(split_date_periods, *date_pairs, split_into=split_into, compute_duration=compute_duration, round=round,
                split_names=split_names, suffix_fmt=suffix_fmt, inplace=True, drop_originals=drop_originals, transforms=None)

        if inplace:
            return
        else:
            return df