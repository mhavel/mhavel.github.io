#!/usr/bin/env python

"""
Pandas tools
"""

from collections import defaultdict

import numpy as np
import pandas as pd


DTYPES_PY = (object, float, int, bool, str, np.datetime64, np.dtype('<M8[ns]'))
DTYPES_MAP = {}
for _ in DTYPES_PY:
    if isinstance(_, np.dtype):
        _dt = _
    else:
        _dt = np.dtype(_)
    _k = _dt.kind
    DTYPES_MAP.update({_:_k, str(_):_k, _k:_k})
    if hasattr(_, '__name__'):
        DTYPES_MAP[_.__name__] = _k


def series_between(s: pd.Series, lower: (int, float), upper: (int, float), inclusive: (bool, str)='left'):
    """returns the values between the given lower and upper limits. Inequalities are controlled by `inclusive`"""
    if isinstance(inclusive, bool):
        incl = 'all' if inclusive else 'none'
    else:
        incl = inclusive
    
    if incl in ('all', 'none'):
        return s.between(lower, upper, inclusive=incl == 'all')
    else:
        if incl == 'left':
            loc = (s >= lower) & (s < upper)
        else: # meaning: elif inlc == 'right':
            loc = (s > lower) & (s <= upper)
        return s.loc[loc]


def bin_series(s: pd.Series, bins: (str, int, list, callable, bool)=10, **kwargs):
    if isinstance(bins, bool) and bins and s.dtype.kind in ('i', 'b'):
        u = s.unique()
        diff = u[1:] - u[:-1]
        b = [u[0] - diff[0] / 2.] + (u[1:] - diff / 2.).tolist() + [u[-1] + diff[-1] / 2.]  # one bin per value
    elif isinstance(bins, (int, str)):
        b = bins  # int or str
        hist = True
    elif not callable(bins):
        b = bins  # sequence
    else:
        be = bins(s)  # ie. take the series as input, and return bin edges
    
    c, be = np.histogram(s.values, bins=b, **kwargs)
    return c, be


def fractions_per_target_classes(x: pd.DataFrame, target: (pd.Series, str), bins: (str, int, list, callable, bool)=None):
    if isinstance(target, str):
        y = x.loc[:, target]
        t = target
    else:
        y = target
        t = target.name

    assert y.dtype.kind in ('b', 'i', 'U', 'S'), 'only bool, int, and string types are allowed for the target (categorical feature)'
    classes = y.unique()

    if bins is None:
        m = x.shape[0]
        # return classes, and vector of class' fractions wrt. total number of sample
        return classes, {_: y.loc[y == _].size / m for _ in classes}, None

    fracs = defaultdict(dict)
    bin_edges = {}
    for f in x:
        if f == t:
            continue
        
        s = x.loc[:, f]
        hc, be = bin_series(s, bins=bins)
        bin_edges[f] = be

        locs = [y == _ for _ in classes]
        _xc = [s.loc[_] for _ in locs]

        for i, c in enumerate(classes):
            fracs[c][f] = [series_between(_xc[i], be[_], be[_+1], inclusive='left').size / hc[_] if hc[_] else 0 for _ in range(len(be)-1)]
            # fracs[c][f] = [series_between(_xc[i], be[_], be[_+1], inclusive='left').size / s.size for _ in range(len(be)-1)]
    
    return classes, fracs, bin_edges


def filter_by_dtype(df: pd.DataFrame, *dtypes):
    dt = [DTYPES_MAP[_] for _ in dtypes]
    return df.drop([_ for _ in df if df[_].dtype.kind not in dt], axis=1)


def print_counts(df: (pd.DataFrame, pd.Series)):
    """simply print number of unique values and number of NaNs/null in the dataframe"""
    if isinstance(df, pd.Series):
        s = df
        n = s.size
        nv = s.value_counts().size
        if s.dtype.kind in ('O', 'U', 'f'):
            nn = n - s.count()
            print(f'{s.name:.<35s} has {nv:5d} unique and {nn:5d} NaNs/null values {s.name:.>35s}')
        else:
            print(f'{s.name:.<35s} has {nv:5d} unique values')
    
    else:
        n = df.shape[0]
        for c in df:
            s = df.loc[:, c]
            nv = s.value_counts().size
            if s.dtype.kind in ('O', 'U', 'f'):
                nn = n - s.count()
                print(f'{s.name:.<35s} has {nv:5d} unique and {nn:5d} NaNs/null values {s.name:.>35s}')
            else:
                print(f'{s.name:.<35s} has {nv:5d} unique values')



